"""Unit test for meteoric.py"""
import meteoric
import pytest


test_meteors = [
    ["Aachen", "1", "1880", "50.775", "6.08333"],
    ["Aarhus", "2", "1951", "56.18333", "10.23333"],
    ["Abee", "6", "1952", "54.21667", "-113"],
    ["Acapulco", "10", "1976", "16.88333", "-99.9"],
]

def test_load_data():
    """Test case for load_data()"""
    result = meteoric.load_data()
    assert result[0] == ['Aachen', '1', '1880', '50.775', '6.08333']
    assert result[-1] == ['Zulu Queen', '30414', '1976', '33.98333', '-115.68333']

def test_year():
    assert meteoric.year(test_meteors, "1880") == 'The meteor Aachen landed at 50.775 and 6.08333.'
    assert meteoric.year(test_meteors, "1951") == 'The meteor Aarhus landed at 56.18333 and 10.23333.'
    assert meteoric.year(test_meteors, "1950") == "No meteors found for the year 1950"

def test_year_exceptions():
    with pytest.raises(ValueError) as verr:
        meteoric.year(test_meteors, "88") 
    assert str(verr.value) == '88 is invalid. Please enter a valid 4 digit year.'
    
    with pytest.raises(ValueError) as verr:
        meteoric.year(test_meteors , "-1")
    assert str(verr.value) == '-1 is invalid. Please enter a valid 4 digit year.'

    with pytest.raises(ValueError) as verr:
        meteoric.year(test_meteors , "10000")
    assert str(verr.value) == "10000 is invalid. Please enter a valid 4 digit year."

    with pytest.raises(ValueError) as verr:
        meteoric.year(test_meteors, None)
    assert str(verr.value) == "None is invalid. Please enter a valid 4 digit year."

    with pytest.raises(ValueError) as verr:
        meteoric.year(test_meteors, '')
    assert str(verr.value) == " is invalid. Please enter a valid 4 digit year."
    
    with pytest.raises(IndexError) as verr:
        meteoric.year(test_meteors, "5400")
    assert str(verr.value) == "5400 not within valid range."

def test_geo_point():
    assert meteoric.geo_point(test_meteors, "55,64") == "The Meteor Aarhus with ID: 2 landed closest to that location in: 1951"
    assert meteoric.geo_point(test_meteors, "54.21667,-113") == "The Meteor Abee with ID: 6 landed closest to that location in: 1952"

def test_geo_point_exception():
    with pytest.raises(ValueError) as verr:
        meteoric.geo_point(test_meteors, "-100,189")
    assert str(verr.value) == 'Latitude and longitude is out of range.'
    
if __name__ == "__main__":
    pytest.main()    