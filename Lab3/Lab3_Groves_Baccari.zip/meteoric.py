"""
    Module for displaying information about meteor data from the NASA Meteorite Landings dataset:
    https://data.nasa.gov/widgets/gh4g-9sfh

    Created by: Vincent Baccari & Christopher Groves
"""
import sys
import csv
import math
from math import radians, cos, sin, sqrt, atan2, asin

# Constants for specific columns in the csv
METEOR_NAME = 0
METEOR_ID = 1
METEOR_YEAR = 2
METEOR_LAT = 3
METEOR_LON = 4
YEAR_RANGE = range(0,3000)
MAX_LAT = 90
MAX_LON = 180

def load_data():
    """Load meteorite data into a "list of lists".
    Each element in the list corresponds to a single line in the CSV file.
    Each line has 9 elements: name,id,nametype,recclass,mass (g),fall,year,reclat,reclong

    Returns:
        list: a list of lists, where each inner list contains the data for one meteor
    """
    # Vincent implemented the try, except block
    try:
        with open('meteorite_landings.csv', encoding='utf-8', newline='') as csvfile:
            next(csvfile)  # skip the header row
            return list(csv.reader(csvfile))
    except FileNotFoundError:
        raise FileNotFoundError("File not found. Check file path and try again.")
    except Exception as e:
        raise Exception(f"Error loading the file: {e}")


def main():
    """The main function that provides the console interface for the application.
    """
    # attempt to get the command and argument from the CLI or the input() console.
    result = None
    try:
        if len(sys.argv) == 3:
            command = sys.argv[1]
            arg = sys.argv[2]
        else:
            print("Give a command. Options are:")
            print("1. Search by year, input year <year>")
            print("2. Search by latitude and longitude, input geopoint <latitude>,<longitude>")
            command, arg = input("Enter a command: ").split(' ')
    except ValueError:
        print("Invalid command format. Expected 'year <year>' or 'geopoint <latitude>,<longitude>'")
        return

    # Read the CSV file data into a list.
    try:
        meteors = load_data()
        print("File input valid")
    except Exception as e:
        print(e)
        return

    # Add code here to validate command & arg, and then call the functions to process the data.
    # Validates command and arg, then calls the function

    # Chris put together the majority of the validation and Vincent pointed out
    # occasional flaws in logic and fixed a neverending loop Chris accidentally put in.
    if command == '1' or command == 'year':
        try:
            result = year(meteors, arg)
        except Exception as e:
            print(e)
            
    elif command == '2' or command == 'geopoint':
        try:
            lat,lon = arg.strip().split(',')
            if float(lat) and float(lon):
                result = geo_point(meteors,arg)
        except ValueError as e:
            print("Invalid geopoint format. Requires '<latitude>,<longitude>'.",e)
        except UnboundLocalError:
            print(f"{arg} is not valid input. Please enter valid <latitude>,<longitude>.")
            
    else:
        raise ValueError("Incorrect input. Please enter 'year' or 'geopoint'.")

    # Outputs the result
    if result:
        print(result)

# Vincent primarily implemented the year function
def year(meteors, year):
    """Returns meteor sightings for the designated year.

    Args:
        meteors (list): Ordered list of meteor sightings
        year (int): Valid input year from user

    Returns:
        str: A formatted string of result or message indicating no meteors were found.
    """
    
    if not isinstance(year,str):
        raise ValueError(f"{year} is invalid. Please enter a valid 4 digit year.")
    if not year.isdigit() or len(year) != 4:
        raise ValueError(f"{year} is invalid. Please enter a valid 4 digit year.")
    
    year = int(year)
    if year not in YEAR_RANGE:
        raise IndexError(f"{year} not within valid range.")
    
    result = []
    for i in meteors:
        if i[METEOR_YEAR] == str(year):
            if i[METEOR_LAT] and i[METEOR_LON]:
                result.append(f'The meteor {i[METEOR_NAME]} landed at {i[METEOR_LAT]} and {i[METEOR_LON]}.')

    if result:
        return '\n'.join(result)
    return (f"No meteors found for the year {year}")

# Chris primarily implemented the geopoint function
def geo_point(meteors,arg):
    """Searches through list of meteors and returns sightings for the designated global coordinates.

    Args:
        meteors (list): Ordered list of meteor sightings
        geopoint (float): Two floating point numbers separated by a comma

    Returns:
        str: A formatted string of result or message indicating no meteors were found.
    """
    
    lat,lon = arg.split(",")
    nearest_meteor = None
    nearest_distance = math.inf
    
    if float(lat) < -MAX_LAT or float(lat) > MAX_LAT or float(lon) < -MAX_LON or float(lon) > MAX_LON:
        raise ValueError("Latitude and longitude is out of range.")

    for i in meteors:
        if i[METEOR_LAT] != "" and i[METEOR_LON] != "":
            latitude = float(i[METEOR_LAT])
            longitude = float(i[METEOR_LON])
            great_circle = haversine(float(lat),float(lon),latitude, longitude)
            
        if great_circle < nearest_distance:
            nearest_distance = great_circle
            nearest = i
            
    if nearest:
        return (f"The Meteor {nearest[METEOR_NAME]} with ID: {nearest[METEOR_ID]} landed closest to that location in: {nearest[METEOR_YEAR]}")
      
    # Vincent implemented entire haversine function  
def haversine(lon1, lat1, lon2, lat2):
    """Calculate the great circle distance in kilometers between two points. (Specified in decimal degrees)

    Args:
        lon1 (_float_): Input Longitude
        lat1 (_float_): Input Latitude
        lon2 (_float_): Listed Longitude
        lat2 (_float_): Listed Latitude
    """
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371 # Radius of Earth in kilometers
    return c*r

if __name__ == "__main__":
    main()